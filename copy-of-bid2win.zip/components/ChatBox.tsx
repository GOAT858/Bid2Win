
// This file is no longer used as chat functionality has been removed.
export default () => null;
